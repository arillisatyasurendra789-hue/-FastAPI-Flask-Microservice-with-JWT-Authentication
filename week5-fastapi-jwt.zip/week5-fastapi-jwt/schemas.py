from pydantic import BaseModel, EmailStr, Field


class UserCreate(BaseModel):
    username: str = Field(min_length=3, max_length=50)
    email: EmailStr
    password: str = Field(min_length=6, max_length=100)


class UserResponse(BaseModel):
    id: int
    username: str
    email: EmailStr

    class Config:
        from_attributes = True


class TokenResponse(BaseModel):
    access_token: str
    token_type: str


class ProductCreate(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    description: str | None = None
    price: float = Field(gt=0)


class ProductResponse(BaseModel):
    id: int
    name: str
    description: str | None
    price: float
    owner_id: int

    class Config:
        from_attributes = True
