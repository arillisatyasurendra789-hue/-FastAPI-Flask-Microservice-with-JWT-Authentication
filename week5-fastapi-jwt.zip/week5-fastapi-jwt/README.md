# Week 5 - FastAPI Microservice with JWT Authentication

## Python Software Engineering Internship

This project implements a secure RESTful microservice using FastAPI, SQLite,
SQLAlchemy, Pydantic, bcrypt, and JWT authentication.

## Features

- User registration
- Secure bcrypt password hashing
- JWT login and Bearer-token authorization
- Protected product CRUD operations
- SQLite persistence using SQLAlchemy
- Pydantic request validation
- Automatic Swagger/OpenAPI documentation
- Postman collection for API testing

## Project Structure

```text
week5-fastapi-jwt/
├── main.py
├── database.py
├── models.py
├── schemas.py
├── auth.py
├── crud.py
├── requirements.txt
├── README.md
├── .gitignore
├── screenshots/
└── postman/
    └── week5_api_collection.json
```

## Installation

```bash
python -m venv venv
```

Windows:

```bash
venv\Scripts\activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

## Configure JWT Secret

For development, the application has a fallback secret. For a real deployment,
set an environment variable instead.

Windows PowerShell:

```powershell
$env:JWT_SECRET_KEY="replace-with-a-long-random-secret"
```

Linux/macOS:

```bash
export JWT_SECRET_KEY="replace-with-a-long-random-secret"
```

## Run

```bash
uvicorn main:app --reload
```

Open Swagger:

http://127.0.0.1:8000/docs

## API Endpoints

| Method | Endpoint | Auth |
|---|---|---|
| GET | `/` | No |
| POST | `/register` | No |
| POST | `/login` | No |
| GET | `/products` | JWT |
| POST | `/products` | JWT |
| GET | `/products/{id}` | JWT |
| PUT | `/products/{id}` | JWT |
| DELETE | `/products/{id}` | JWT |

## Testing Flow

1. Register a user with `POST /register`.
2. Login using `POST /login`.
3. Copy the returned access token.
4. Click **Authorize** in Swagger and enter the Bearer token.
5. Test product CRUD endpoints.
6. Import the Postman collection from `postman/week5_api_collection.json`.

## Proof Checklist

For the internship submission, capture screenshots of:

- Swagger `/docs`
- Successful registration
- Successful login with JWT
- Authorized CRUD operation
- Unauthorized request returning HTTP 401

The repository should contain the FastAPI source code, `requirements.txt`,
Swagger screenshots, and Postman collection.

## Learning Outcomes

- REST API development
- FastAPI routing
- Pydantic validation
- SQLAlchemy ORM
- SQLite persistence
- Password hashing
- JWT authentication
- Bearer authorization
- CRUD operations
- Swagger/OpenAPI
- Postman testing
- Environment-based secret management
