from sqlalchemy.orm import Session

from auth import hash_password
from models import Product, User
from schemas import ProductCreate, UserCreate


def create_user(db: Session, user_data: UserCreate):
    user = User(
        username=user_data.username,
        email=user_data.email,
        hashed_password=hash_password(user_data.password)
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


def create_product(db: Session, product_data: ProductCreate, owner_id: int):
    product = Product(
        name=product_data.name,
        description=product_data.description,
        price=product_data.price,
        owner_id=owner_id
    )
    db.add(product)
    db.commit()
    db.refresh(product)
    return product


def get_products(db: Session, owner_id: int):
    return db.query(Product).filter(Product.owner_id == owner_id).all()


def get_product(db: Session, product_id: int, owner_id: int):
    return db.query(Product).filter(
        Product.id == product_id,
        Product.owner_id == owner_id
    ).first()


def update_product(db: Session, product, product_data: ProductCreate):
    product.name = product_data.name
    product.description = product_data.description
    product.price = product_data.price
    db.commit()
    db.refresh(product)
    return product


def delete_product(db: Session, product):
    db.delete(product)
    db.commit()
