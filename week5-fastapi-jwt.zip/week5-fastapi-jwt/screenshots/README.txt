Capture and place these proof screenshots here after running the API:
1. swagger.png - /docs showing all endpoints
2. register.png - successful POST /register
3. login.png - successful POST /login showing JWT
4. authorized-crud.png - authenticated CRUD response
5. unauthorized-401.png - protected endpoint without token
